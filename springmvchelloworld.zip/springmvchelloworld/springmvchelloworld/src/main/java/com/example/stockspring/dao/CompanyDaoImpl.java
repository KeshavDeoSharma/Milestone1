package com.example.stockspring.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.stockspring.model.Company;
import com.example.stockspring.model.Sector;

@Repository
public class CompanyDaoImpl implements CompanyDao{

	public Company insertCompany(Company company) throws SQLException  {
		/*		Connection conn=DriverManager.getConnection("","test","test123");
		PreparedStatement ps=conn.prepareStatement("insert into company (clo) value(?,?,?,?,?)")
		ps.setInt(1, company.getCompanyId());
		ps.executeUpdate();
		*/
		return null;
	}

	
	public List<Company> getCompanyList() throws SQLException{
		System.out.println("inside list dao");
		List <Company> companyList=new ArrayList<Company>();
		try {
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("select * from company");
		ResultSet rs=	ps.executeQuery();
		
		Company company=null;
		while(rs.next()){
			 company=new Company();
			company.setCompany_code(rs.getInt("company_code"));
			company.setCompany_Name(rs.getString("company_Name"));
			company.setTurnover(rs.getDouble("turnover"));
			company.setCeo(rs.getString("ceo"));
			company.setBoardOfDirectors(rs.getString("boardOfDirectors"));
			Sector sector=new Sector();
			sector.setSector_id(rs.getInt("sector_id"));
			sector.setBreifwriteup(rs.getString("breifwriteup"));
			sector.setStock_Code(rs.getInt("stock_Code"));
			company.setSector(sector);
			companyList.add(company);
		}
		}catch(SQLException e)
		{
			System.out.println(e);
			throw e;
		}
		return companyList;
	}

	
	
	
	
	
	
	@Override
	public Company updateCompany(Company company) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static void main(String []args) throws Exception{
		CompanyDaoImpl dao=new CompanyDaoImpl();
		//Company compnay=new Company();
		//compnay.setCompanyId(1001);
		//dao.insertCompany(compnay);
		
		System.out.println(dao.getCompanyList());
	}

}
