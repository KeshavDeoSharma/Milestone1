package com.example.stockspring.controller;

import java.sql.SQLException;
import java.util.List;

import com.example.stockspring.model.Stock;
import com.example.stockspring.service.StockService;

public class StockControlleImpl implements StockController {
	private StockService stockService;
	
	@Override
	public Stock insertStock(Stock stock) throws SQLException,ClassNotFoundException{
		stockService.insertStock(stock);
		return  stock;
	}
	@Override
	public List<Stock> getStockList() throws Exception{
		return stockService.getStockList();
		
	}

}
