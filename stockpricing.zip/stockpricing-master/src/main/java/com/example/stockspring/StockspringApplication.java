package com.example.stockspring;

import java.util.Random;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.stockspring.controller.CompanyController;
import com.example.stockspring.model.Company;
import com.example.stockspring.model.Sector;

//@SpringBootApplication
public class StockspringApplication {

	public static void main(String[] args) throws Exception {
		System.out.println("before the container");
		Company company=new Company();
		company.setBoardOfDirectors("df");
		Random random=new Random();
		company.setCompanyId(random.nextInt(1000));
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("spring.xml");
		System.out.println("after the container");
		CompanyController companyController=(CompanyController)applicationContext.getBean("companyControllerImpl");
		company.setCompanyId(random.nextInt(1000));
		company.setBoardOfDirectors("Keshav Deo Sharma");
		Sector sector=new Sector();
		sector.setSector_id(1);
		sector.setBreifwriteup("abcdg");
		sector.setStock_Code(102);
		company.setSector(sector);
		company.setCeo("John Lieu");
		company.setCompanyName("Cognizant ");
		company.setTurnover(1000000);
				
		companyController.insertCompany(company);
System.out.println(companyController.getCompanyList());
	}

}
