package com.example.stockspring.model;

public class Company {

	private int companyId; 
	private String companyName;
	private String boardOfDirectors;
	private double turnover;
	private Sector sector;
	private String Ceo;
	
	

	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public double getTurnover() {
		return turnover;
	}
	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}
	public String getCeo() {
		return Ceo;
	}
	public void setCeo(String ceo) {
		Ceo = ceo;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}
	public Sector getSector() {
		return sector;
	}
	public void setSector(Sector sector) {
		this.sector = sector;
	}
	
	public Company(int companyId, String companyName, String boardOfDirectors, double turnover, Sector sector,
			String ceo) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.boardOfDirectors = boardOfDirectors;
		this.turnover = turnover;
		this.sector = sector;
		Ceo = ceo;
	}
	
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String toString(){
		return "id:"+this.getCompanyId()+" directors:"+this.getBoardOfDirectors();
	}
}
