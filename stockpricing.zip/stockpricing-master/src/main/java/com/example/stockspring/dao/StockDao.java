package com.example.stockspring.dao;

import java.sql.SQLException;
import java.util.List;

import com.example.stockspring.model.Stock;

public interface StockDao {

	boolean insertStock(Stock stock) throws SQLException;

	List<Stock> getStockList() throws SQLException;

}