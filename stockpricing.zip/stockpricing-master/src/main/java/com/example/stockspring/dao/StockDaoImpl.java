package com.example.stockspring.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.example.stockspring.model.*;

public class StockDaoImpl implements StockDao{

	@Override
	public boolean insertStock(com.example.stockspring.model.Stock stock) throws SQLException {
		// TODO Auto-generated method stub
		boolean value=true;
		try {
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("insert into stockexchange(stockExchange_name, brief, contactaddress, remarks) values(?,?,?,?)");
		ps.setString(1,stock.getStockExchangeName());
		ps.setString(2,stock.getBrief());
		ps.setString(3,stock.getContactAddress());
		ps.setString(4,stock.getRemarks());
		value=ps.execute();
		ps.close();
		conn.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return value;
	}

	@Override
	public List<Stock> getStockList() throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/world?useSSL=false","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("select * from stockexchange");
		ResultSet rs=ps.executeQuery();
		List<com.example.stockspring.model.Stock> stockList=new ArrayList<Stock>();
		com.example.stockspring.model.Stock stock=null;
		while(rs.next()) {
			stock=new Stock();
			
			 int stockExchangeId=rs.getInt("stockexchange_id");
			 stock.setStockExchangeId(stockExchangeId);
			 
			stock.setStockExchangeName(rs.getString("stockExchange_name"));
			
			
			stock.setBrief(rs.getString("brief"));
			stock.setContactAddress(rs.getString("contactaddress"));
			stock.setRemarks(rs.getString("remarks"));
			stockList.add(stock);
		}
		
		return stockList;
		
	}
	public static void main(String args[]) throws SQLException
	{
		StockDao stockDao=new StockDaoImpl();
		Stock stock=new Stock();
		stock.setBrief("hi hello");
		stock.setContactAddress("belur");
		stock.setRemarks("doing good");
		stock.setStockExchangeName("bse/nse");
		System.out.println(stockDao.insertStock(stock));
	System.out.println(stockDao.getStockList());
	
	}

	

}