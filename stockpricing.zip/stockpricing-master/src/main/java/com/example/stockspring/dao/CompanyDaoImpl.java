package com.example.stockspring.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.example.stockspring.model.Company;

@Repository
public class CompanyDaoImpl implements CompanyDao{

	public Company insertCompany(Company company) throws SQLException, ClassNotFoundException  {
	int rs;
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");  
		
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","pass@word1");
			
			PreparedStatement ps=conn.prepareStatement("insert into company(company_code, company_Name, turnover, ceo, boardofdirectors, sector_id, breifwriteup, stock_Code) values(?,?,?,?,?,?,?,?)");
		ps.setString(4, company.getCeo());
		 ps.setString(2,company.getCompanyName());
		ps.setString(5,company.getBoardOfDirectors());
		ps.setInt(1,company.getCompanyId());
		ps.setInt(6, company.getSector().getSector_id());
		ps.setDouble(3, company.getTurnover());
		ps.setInt(8,company.getSector().getStock_Code());
		ps.setString(7,company.getSector().getBreifwriteup());
		
		 rs=ps.executeUpdate();
		 if(rs>0)
		 {System.out.println("Successfully Added");
		 
		 }
		 }
		catch(SQLException e)
		{
		e.printStackTrace();
		}
		return company;
		 
			
	}

	
	public List<Company> getCompanyList() throws SQLException {
		List <Company> companyList=new ArrayList<Company>();
		try{
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","pass@word1");
		PreparedStatement ps=conn.prepareStatement("select * from company");
		ResultSet rs=	ps.executeQuery();
		Company company=null;
		while(rs.next()){
			 company=new Company();
			 int companyId=rs.getInt("company_code");
			company.setCompanyId(companyId);;
			company.setBoardOfDirectors(rs.getString("boardofdirectors"));
			companyList.add(company);
		}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return companyList;
	}
		
		@Override
		public Company updateCompany(Company company) {
			int rs;
			try {
				Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","pass@word1");
				PreparedStatement ps=conn.prepareStatement("update company set turnover=?,ceo=?,boardofdirectors=?,sector_id=?,breifwriteup=?,stock_code=? where company_code=?");
				ps.setDouble(1, company.getTurnover());
				ps.setString(2, company.getCeo());
				ps.setString(3, company.getBoardOfDirectors());
				ps.setInt(4,company.getSector().getSector_id());
				ps.setString(5,company.getSector().getBreifwriteup());
				ps.setInt(6,1009);
				ps.setInt(7,company.getCompanyId() );
				//ps.setInt(1, );
				 rs=ps.executeUpdate();
				
				ps.close();
				conn.close();
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			return company;
		}

	}
	
	

