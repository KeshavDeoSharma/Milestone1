package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import com.example.stockspring.model.Stock;

public interface StockService {

	Stock insertStock(Stock stock) throws SQLException, ClassNotFoundException;

	List<Stock> getStockList() throws Exception;

}