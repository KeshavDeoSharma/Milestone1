package com.example.stockspring.service;

import java.sql.SQLException;
import java.util.List;

import com.example.stockspring.dao.StockDao;
import com.example.stockspring.model.Stock;

public class StockServiceImpl implements StockService {
	private StockDao stockDao;
	
	@Override
	public Stock insertStock(Stock stock) throws SQLException,ClassNotFoundException{
		stockDao.insertStock(stock);
		return  stock;
	}
	@Override
	public List<Stock> getStockList() throws Exception{
		return stockDao.getStockList();
	}
	

}
